<?php define('WP_CACHE', true);
/** Enable W3 Total Cache */
 // Added by W3 Total Cache

//define('WP_MEMORY_LIMIT', '96M');

define('WP_HOME','http://www.vw-ws.com');
define('WP_SITEURL','http://www.vw-ws.com/');

define('folderimg', 'http://img.vw-ws.com/' );
define('folderhdr', 'http://hdr.vw-ws.com/' );
define('folderbg', 'http://bg.vw-ws.com/' );
define('folderbtn', 'http://btn.vw-ws.com/' );
define('folderftr', 'http://ftr.vw-ws.com/' );
define('folderscripts', 'http://scripts.vw-ws.com/' );
define('folderstyles', 'http://styles.vw-ws.com/' );
define('folderswf', 'http://swf.vw-ws.com/' );
define('folderguide', 'http://guide.vw-ws.com/' );
define('folderschool', 'http://school.vw-ws.com/' );
define('folderaudio', 'http://audio.vw-ws.com/' );

/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */

/** enable multi-site (wordpressmu) */
define('WP_ALLOW_MULTISITE', true);

define('DB_NAME', 'vwwscom_dbyfp4');

/** MySQL database username */
define('DB_USER', 'vwwscom_dbyfp4');

/** MySQL database password */
define('DB_PASSWORD', '10d8cPdSqi');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '7p5xhksnff5hx2i76uwuie9mmrxyddvew9cefwj8qt0tvphszdapyspjbqrusr2h');
define('SECURE_AUTH_KEY',  'mwtdalzqafquac0p4jnk67klyr7ht0cf5fjm5mh5koaoskgz4lmtuqcs3gvz9qtc');
define('LOGGED_IN_KEY',    'c73sdc8kenwzuckjzj2nnbl6kz8vvbob3lfiiexaeo0zyya741gyx7xueyb7n4oe');
define('NONCE_KEY',        '37qlyq2dziavkzyh64ze2dbehqkr1m6iwbz1sztl6xv0e3lwpehf222tshslqqjd');
define('AUTH_SALT',        '1ilsrfkelmm8nsiho1hitlhaefygwr2kjzqb50fbnkwhp0jhhbcz0vdoroxuqgxe');
define('SECURE_AUTH_SALT', 'a6zwmhsjrzngbhzpy7fcryijiki0tzihhayorhkyl4ukre1wp5fi6j1nh8gydimb');
define('LOGGED_IN_SALT',   'kbjpmjo8ofgxfymwc97nzqgcxigvstvqqq4tjrpiijqnw1mbtkhmjjphz3c0goup');
define('NONCE_SALT',       'ecljd3rtuolcaoowv5cwofqist2xkjaxdktzyfojhzbiuomvu2j4fzyym87hzjlr');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'yfp4_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress.  A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define ('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */

define('WP_DEBUG', false);

define( 'SUNRISE', 'on' );

define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', true);
$base = '/';
define('DOMAIN_CURRENT_SITE', 'www.vw-ws.com');
define('PATH_CURRENT_SITE', '/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);

define('WP_POST_REVISIONS', 12);

define('DISABLE_WP_CRON', true);

@ini_set('log_errors','On');
@ini_set('display_errors','Off');
@ini_set('error_log','/home/vwwscom/public_html/logs/php_error.log');

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
ini_set('display_errors', 0);
require_once(ABSPATH . 'wp-settings.php');